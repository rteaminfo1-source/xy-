<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация — Rai</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form-container">
    <h2>Регистрация</h2>

    <form method="post">
        <input type="text" name="name" placeholder="Имя" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Пароль" required>
        <button class="btn">Создать аккаунт</button>
    </form>

    <?php
    if ($_POST) {
        $_SESSION["user"] = $_POST["email"];
        echo "<script>location.href='chat.php';</script>";
    }
    ?>

    <p>Уже есть аккаунт? <a href="login.php">Вход</a></p>
</div>

</body>
</html>
