<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход — Rai</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="form-container">
    <h2>Вход</h2>

    <form method="post">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Пароль" required>
        <button class="btn">Войти</button>
    </form>

    <?php
    if ($_POST) {
        $_SESSION["user"] = $_POST["email"];
        echo "<script>location.href='chat.php';</script>";
    }
    ?>

    <p>Нет аккаунта? <a href="register.php">Регистрация</a></p>
</div>

</body>
</html>
