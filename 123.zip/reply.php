<?php
session_start();

function load($f,$d){return file_exists($f)?json_decode(file_get_contents($f),true):$d;}
function save($f,$d){file_put_contents($f,json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));}

$id=$_POST["id"]??"";
$reply=trim($_POST["reply"]??"");
$delete_only=isset($_POST["delete_only"]);

$messages=load("messages.json",[]);
$new=[];
$found=null;

foreach($messages as $m){
    if((string)$m["id"]===(string)$id){$found=$m;}else{$new[]=$m;}
}

if(!$found){echo "<script>alert('Сообщение не найдено');history.back();</script>";exit;}

if($delete_only){
    save("messages.json",$new);
    echo "<script>alert('Удалено');location.href='messages_admin.php';</script>";
    exit;
}

if($reply===""){echo "<script>alert('Введите ответ');history.back();</script>";exit;}

$email=$found["email"];
$name=$found["name"];

$subject="Ответ на ваше сообщение в Rteam";
$body="Здравствуйте, $name!\n\nВаше сообщение:\n{$found["text"]}\n\nОтвет:\n$reply\n\nС уважением,\nRteam";

@mail($email,$subject,$body,"From: noreply@rteam.local\r\n");

save("messages.json",$new);

echo "<script>alert('Ответ отправлен и сообщение удалено.');location.href='messages_admin.php';</script>";
