<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: POST, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$apiKey = "XljzoS_k9p2xrdivM6tRh42RsjHyrCRJ0zx-lPw8iniBybBMVfjgux147DIeKgrGG8HjT3BlbkFJUgyz2FxcCHWMchsVaKxyHXheQQEvwvO8RrhPlxdLBGZH84kJtN5QnynUaMGCXVA25z8zDii8IA";

$input = json_decode(file_get_contents('php://input'), true);
$text = $input["message"] ?? "";

if (!$text) {
    echo json_encode(["error" => "Пустой запрос"], JSON_UNESCAPED_UNICODE);
    exit;
}

$url = "https://api.openai.com/v1/chat/completions";

$data = [
    "model" => "gpt-4o-mini",
    "messages" => [
        [
            "role" => "system",
            "content" => "Ты — Rai, помощник для разработчиков. Помогаешь с кодом, объясняешь ошибки, предлагаешь варианты решений. Пиши кратко и по делу."
        ],
        [
            "role" => "user",
            "content" => $text
        ]
    ]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: " . "Bearer " . $apiKey
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

$response = curl_exec($ch);
curl_close($ch);

$json = json_decode($response, true);
$answer = $json["choices"][0]["message"]["content"] ?? "Результат не получен.";

echo json_encode(["answer" => $answer], JSON_UNESCAPED_UNICODE);
